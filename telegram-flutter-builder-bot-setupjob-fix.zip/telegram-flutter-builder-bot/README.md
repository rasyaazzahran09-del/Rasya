# Telegram Flutter ZIP Builder Bot

Bot Telegram berbasis **Node.js native tanpa dependency npm eksternal** untuk dijalankan dengan startup:

```bash
node index.js
```

Bot ini menerima file ZIP project Flutter dari Telegram, lalu:
1. mengunggah ZIP ke repository GitHub,
2. memicu GitHub Actions,
3. GitHub Actions memasang Flutter SDK di runner GitHub,
4. membangun APK,
5. mengunggah APK sebagai release asset,
6. bot mengunduh APK itu dan mengirimnya kembali ke Telegram.

## Kenapa ini cocok untuk Pterodactyl panel?
- Tidak perlu egg khusus Flutter.
- Panel **tidak perlu Flutter SDK atau Android SDK lokal**.
- Proses berat build dilakukan oleh **GitHub Actions**.
- Startup cukup `node index.js`.

## File utama
- `index.js` → bot utama
- `config.js` → konfigurasi
- `package.json` → startup Node
- `.github/workflows/build-flutter-apk.yml` → workflow builder di GitHub

## Kebutuhan minimal
- Node.js 18+
- Telegram bot token
- GitHub token
- Repository GitHub kosong / target repo yang bisa ditulis

## Pengaturan token GitHub
Gunakan token yang bisa mengakses:
- Contents: Read and Write
- Actions: Read and Write
- Metadata: Read
- Releases: Read and Write

## Langkah pakai
1. Upload semua file ini ke panel.
2. Edit `config.js` atau isi lewat environment variable.
3. Jalankan dengan startup:
   ```bash
   node index.js
   ```
4. Di Telegram:
   - `/setup owner/repo`
   - `/branch main`
   - `/initrepo`
   - `/build`
   - kirim ZIP project Flutter

## Batasan yang jujur
Tidak mungkin mengubah project Flutter menjadi APK **tanpa Flutter SDK sama sekali di mana pun**. Solusi ini memindahkan Flutter SDK ke GitHub Actions, sehingga **panel tetap tidak perlu Flutter SDK**.

## Catatan keamanan
- Jangan hardcode token produksi di source publik.
- Simpan token di environment variable bila memungkinkan.
- Batasi ukuran ZIP.
- Gunakan repo terpisah khusus build.
- Jangan beri akses token lebih luas dari yang dibutuhkan.
