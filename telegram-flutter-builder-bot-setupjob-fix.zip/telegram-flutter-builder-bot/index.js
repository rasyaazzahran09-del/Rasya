'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const https = require('https');
const { URL } = require('url');
const config = require('./config');

const state = {
  offset: 0,
  pendingBuildChats: new Set(),
  activeBuilds: new Map(),
  lastLogsByChat: new Map(),
  chatConfigPath: path.join(__dirname, 'data', 'chat-config.json')
};

ensureDir(path.dirname(state.chatConfigPath));
const chatConfig = loadJson(state.chatConfigPath, {});

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function loadJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function saveJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}

function log(...args) {
  console.log(new Date().toISOString(), '-', ...args);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function safeJsonParse(text) {
  try {
    return JSON.parse(text);
  } catch (_) {
    return null;
  }
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function shorten(text, max = 3500) {
  const value = String(text || '');
  return value.length > max ? `${value.slice(0, max - 3)}...` : value;
}

function nowIso() {
  return new Date().toISOString();
}

function createHttpsRequest(method, urlString, headers = {}, bodyBuffer = null, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const target = new URL(urlString);
    const req = https.request({
      protocol: target.protocol,
      hostname: target.hostname,
      port: target.port || 443,
      path: `${target.pathname}${target.search}`,
      method,
      headers,
      timeout: timeoutMs
    }, (res) => {
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => resolve({ statusCode: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });

    req.on('timeout', () => req.destroy(new Error('Request timeout')));
    req.on('error', reject);
    if (bodyBuffer) req.write(bodyBuffer);
    req.end();
  });
}

async function apiJson(method, urlString, headers = {}, payload = null, acceptableStatuses = [200, 201, 202, 204]) {
  const bodyBuffer = payload ? Buffer.from(JSON.stringify(payload), 'utf8') : null;
  const mergedHeaders = {
    'User-Agent': config.appName,
    'Accept': 'application/json',
    ...headers
  };

  if (bodyBuffer) {
    mergedHeaders['Content-Type'] = 'application/json';
    mergedHeaders['Content-Length'] = bodyBuffer.length;
  }

  const response = await createHttpsRequest(method, urlString, mergedHeaders, bodyBuffer, 120000);
  const text = response.body.toString('utf8');
  const maybeJson = text ? safeJsonParse(text) : null;

  if (!acceptableStatuses.includes(response.statusCode)) {
    throw new Error(`${method} ${urlString} gagal (${response.statusCode}): ${text.slice(0, 1200)}`);
  }

  return { statusCode: response.statusCode, headers: response.headers, data: maybeJson, text, body: response.body };
}

function tgApiUrl(method) {
  return `https://api.telegram.org/bot${config.telegramBotToken}/${method}`;
}

async function telegramCall(method, payload) {
  const res = await apiJson('POST', tgApiUrl(method), {}, payload, [200]);
  if (!res.data || !res.data.ok) throw new Error(`Telegram API ${method} gagal: ${res.text.slice(0, 1000)}`);
  return res.data.result;
}

async function sendMessage(chatId, text, extra = {}) {
  return telegramCall('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    ...extra
  });
}

async function sendPhoto(chatId, photo, caption, extra = {}) {
  return telegramCall('sendPhoto', {
    chat_id: chatId,
    photo,
    caption,
    parse_mode: 'HTML',
    ...extra
  });
}

async function sendDocument(chatId, fileName, buffer, caption = '') {
  const boundary = `----NodeForm${crypto.randomBytes(12).toString('hex')}`;
  const parts = [];
  function pushField(name, value) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`, 'utf8'));
  }
  pushField('chat_id', String(chatId));
  if (caption) pushField('caption', caption);

  parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="document"; filename="${fileName}"\r\nContent-Type: application/octet-stream\r\n\r\n`, 'utf8'));
  parts.push(buffer);
  parts.push(Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8'));

  const bodyBuffer = Buffer.concat(parts);
  const res = await createHttpsRequest('POST', tgApiUrl('sendDocument'), {
    'User-Agent': config.appName,
    'Content-Type': `multipart/form-data; boundary=${boundary}`,
    'Content-Length': bodyBuffer.length
  }, bodyBuffer, 120000);

  const text = res.body.toString('utf8');
  const json = safeJsonParse(text);
  if (res.statusCode !== 200 || !json || !json.ok) {
    throw new Error(`Telegram sendDocument gagal (${res.statusCode}): ${text.slice(0, 1000)}`);
  }
  return json.result;
}

function githubHeaders(extra = {}) {
  return {
    'Authorization': `Bearer ${config.githubToken}`,
    'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': config.appName,
    ...extra
  };
}

async function githubJson(method, apiPath, payload = null, acceptableStatuses = [200]) {
  return apiJson(method, `https://api.github.com${apiPath}`, githubHeaders(), payload, acceptableStatuses);
}

async function githubBinary(method, apiPath, extraHeaders = {}, acceptableStatuses = [200]) {
  const response = await createHttpsRequest(method, `https://api.github.com${apiPath}`, githubHeaders(extraHeaders), null, 120000);
  if (!acceptableStatuses.includes(response.statusCode)) {
    throw new Error(`GitHub binary ${apiPath} gagal (${response.statusCode}): ${response.body.toString('utf8').slice(0, 1200)}`);
  }
  return response;
}

function getChatSettings(chatId) {
  return chatConfig[String(chatId)] || {
    owner: config.defaultRepoOwner,
    repo: config.defaultRepoName,
    branch: config.defaultBranch
  };
}

function setChatSettings(chatId, nextValue) {
  chatConfig[String(chatId)] = nextValue;
  saveJson(state.chatConfigPath, chatConfig);
}

function sanitizeName(name) {
  return String(name || '').replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 100) || 'project.zip';
}

function buildTag(buildId) {
  return `build-${buildId}`;
}

function randomId(prefix = 'bld') {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
}

function usageText() {
  return [
    '<b>Bot Build Flutter ZIP ➜ APK</b>',
    '',
    'Perintah:',
    '/start - tampilkan bantuan',
    '/help - tampilkan bantuan',
    '/setup owner/repo - set repo GitHub tujuan',
    '/branch nama-branch - set branch workflow',
    '/repo - lihat repo aktif',
    '/initrepo - pasang / update workflow ke repo aktif',
    '/build - kirim ZIP project Flutter setelah perintah ini',
    '/status - lihat build aktif',
    '/lastlog - kirim ulang log error build terakhir',
    '',
    'Catatan:',
    '- ZIP harus berisi project Flutter yang valid.',
    '- Build berjalan di GitHub Actions.',
    '- APK akan dikirim ke bot saat build sukses.',
    '- Kalau gagal, bot akan kirim ringkasan error dan file log yang tersedia.'
  ].join('\n');
}

function startKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: 'Setup Repo', callback_data: 'noop_setup' },
        { text: 'Build ZIP', callback_data: 'noop_build' }
      ],
      [
        { text: 'Init Repo', callback_data: 'noop_init' },
        { text: 'Status', callback_data: 'noop_status' }
      ]
    ]
  };
}

async function sendStart(chatId) {
  const caption = usageText();
  const replyMarkup = { reply_markup: startKeyboard() };
  if (config.startPhotoFileId) {
    await sendPhoto(chatId, config.startPhotoFileId, caption, replyMarkup);
    return;
  }
  if (config.startPhotoUrl) {
    await sendPhoto(chatId, config.startPhotoUrl, caption, replyMarkup);
    return;
  }
  await sendMessage(chatId, caption, replyMarkup);
}

async function getTelegramFile(fileId) {
  const result = await telegramCall('getFile', { file_id: fileId });
  if (!result || !result.file_path) throw new Error('Tidak bisa membaca file dari Telegram.');
  const fileUrl = `https://api.telegram.org/file/bot${config.telegramBotToken}/${result.file_path}`;
  const response = await createHttpsRequest('GET', fileUrl, { 'User-Agent': config.appName }, null, 120000);
  if (response.statusCode !== 200) throw new Error(`Gagal download file Telegram (${response.statusCode})`);
  return { filePath: result.file_path, buffer: response.body };
}

async function ensureRepoAccessible(owner, repo) {
  await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`, null, [200]);
}

async function upsertRepoFile(owner, repo, branch, filePath, contentString, commitMessage) {
  let sha = null;
  try {
    const current = await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodeURIComponent(filePath)}?ref=${encodeURIComponent(branch)}`, null, [200]);
    sha = current.data && current.data.sha ? current.data.sha : null;
  } catch (err) {
    if (!String(err.message).includes('(404)')) throw err;
  }

  const payload = {
    message: commitMessage,
    content: Buffer.from(contentString, 'utf8').toString('base64'),
    branch
  };
  if (sha) payload.sha = sha;

  await githubJson('PUT', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodeURIComponent(filePath)}`, payload, [200, 201]);
}

async function uploadSourceZip(owner, repo, branch, sourceZipBuffer, originalName, buildId) {
  const remotePath = `${config.sourceZipPath}/${buildId}-${sanitizeName(originalName)}`;
  const payload = {
    message: `build: upload ${buildId}`,
    content: sourceZipBuffer.toString('base64'),
    branch
  };
  await githubJson('PUT', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodeURIComponent(remotePath)}`, payload, [200, 201]);
  return remotePath;
}

async function dispatchWorkflow(owner, repo, branch, inputs) {
  await githubJson('POST', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/workflows/${encodeURIComponent(config.workflowFileName)}/dispatches`, {
    ref: branch,
    inputs
  }, [204]);
}

async function findWorkflowRun(owner, repo, branch, buildId) {
  const res = await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/workflows/${encodeURIComponent(config.workflowFileName)}/runs?branch=${encodeURIComponent(branch)}&event=workflow_dispatch&per_page=30`, null, [200]);
  const runs = (res.data && res.data.workflow_runs) || [];
  const exact = runs.find((run) => run.display_title && run.display_title.includes(buildId));
  if (exact) return exact;
  return runs.find((run) => run.name === 'Build Flutter APK' && run.head_branch === branch) || null;
}

async function getRun(owner, repo, runId) {
  const res = await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/runs/${runId}`, null, [200]);
  return res.data;
}

async function getRunJobs(owner, repo, runId) {
  const res = await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/runs/${runId}/jobs?per_page=100`, null, [200]);
  return res.data && Array.isArray(res.data.jobs) ? res.data.jobs : [];
}

async function listRunArtifacts(owner, repo, runId) {
  const res = await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/runs/${runId}/artifacts?per_page=100`, null, [200]);
  return res.data && Array.isArray(res.data.artifacts) ? res.data.artifacts : [];
}

async function downloadArtifactZip(owner, repo, artifactId) {
  const res = await githubBinary('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/artifacts/${artifactId}/zip`, {}, [200, 302]);
  if (res.statusCode === 302 && res.headers.location) {
    const redirected = await createHttpsRequest('GET', res.headers.location, { 'User-Agent': config.appName }, null, 120000);
    if (redirected.statusCode !== 200) throw new Error(`Gagal download artifact (${redirected.statusCode})`);
    return redirected.body;
  }
  return res.body;
}

async function findReleaseAsset(owner, repo, tag) {
  const release = await githubJson('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/releases/tags/${encodeURIComponent(tag)}`, null, [200]);
  const assets = release.data && Array.isArray(release.data.assets) ? release.data.assets : [];
  return assets.find((asset) => asset.name && asset.name.endsWith('.apk')) || null;
}

async function downloadReleaseAsset(owner, repo, assetId) {
  const res = await githubBinary('GET', `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/releases/assets/${assetId}`, {
    Accept: 'application/octet-stream'
  }, [200, 302]);

  if (res.statusCode === 302 && res.headers.location) {
    const redirected = await createHttpsRequest('GET', res.headers.location, { 'User-Agent': config.appName }, null, 120000);
    if (redirected.statusCode !== 200) throw new Error(`Gagal download asset release (${redirected.statusCode})`);
    return redirected.body;
  }
  return res.body;
}

function formatJobSummary(jobs) {
  if (!jobs.length) return 'Tidak ada detail job dari GitHub Actions.';
  const lines = ['Ringkasan job / step yang gagal:'];
  for (const job of jobs) {
    const failedSteps = (job.steps || []).filter((step) => ['failure', 'cancelled', 'timed_out'].includes(step.conclusion));
    if (!failedSteps.length && !['failure', 'cancelled', 'timed_out'].includes(job.conclusion)) continue;
    lines.push(`\nJob: ${job.name}`);
    lines.push(`Status: ${job.status} / ${job.conclusion || 'unknown'}`);
    for (const step of failedSteps) {
      lines.push(`- Step gagal: ${step.name} (${step.conclusion})`);
      if (step.number != null) lines.push(`  Nomor step: ${step.number}`);
    }
    if (job.html_url) lines.push(`Lihat job: ${job.html_url}`);
  }
  return lines.join('\n');
}

async function sendBuildFailureLogs(build, run, jobs) {
  const summaryText = [
    `<b>Build gagal</b>`,
    `ID: <code>${build.buildId}</code>`,
    `Repo: <code>${escapeHtml(build.owner)}/${escapeHtml(build.repo)}</code>`,
    `Kesimpulan: <code>${escapeHtml(run.conclusion || 'unknown')}</code>`,
    run.html_url ? `Run: ${run.html_url}` : ''
  ].filter(Boolean).join('\n');

  await sendMessage(build.chatId, summaryText);

  const jobSummary = formatJobSummary(jobs);
  const summaryBuffer = Buffer.from(`${jobSummary}\n\nWaktu: ${nowIso()}\n`, 'utf8');
  state.lastLogsByChat.set(build.chatId, [{ name: `error-summary-${build.buildId}.txt`, buffer: summaryBuffer }]);
  await sendDocument(build.chatId, `error-summary-${build.buildId}.txt`, summaryBuffer, `Ringkasan error ${build.buildId}`);

  try {
    const artifacts = await listRunArtifacts(build.owner, build.repo, build.runId);
    const logArtifact = artifacts.find((item) => item.name === `build-logs-${build.buildId}` || item.name === `build-debug-${build.buildId}`);
    if (logArtifact) {
      const zipBuffer = await downloadArtifactZip(build.owner, build.repo, logArtifact.id);
      const current = state.lastLogsByChat.get(build.chatId) || [];
      current.push({ name: `${logArtifact.name}.zip`, buffer: zipBuffer });
      state.lastLogsByChat.set(build.chatId, current);
      await sendDocument(build.chatId, `${logArtifact.name}.zip`, zipBuffer, `Log lengkap build ${build.buildId}`);
    }
  } catch (err) {
    log('send artifact logs error', err);
    await sendMessage(build.chatId, `Log artifact tidak berhasil diambil, tapi ringkasan error sudah dikirim.\n<code>${escapeHtml(shorten(err.message, 900))}</code>`);
  }
}

async function initRepoFiles(owner, repo, branch) {
  await ensureRepoAccessible(owner, repo);
  await upsertRepoFile(owner, repo, branch, '.github/workflows/build-flutter-apk.yml', workflowContent(), 'chore: add Flutter APK build workflow');
  await upsertRepoFile(owner, repo, branch, '.gitignore', 'build-output/\ninput/*.zip\n', 'chore: add gitignore');
}

function workflowContent() {
  return [
    'name: Build Flutter APK',
    '',
    'on:',
    '  workflow_dispatch:',
    '    inputs:',
    '      build_id:',
    '        description: Unique build id',
    '        required: true',
    '        type: string',
    '      zip_path:',
    '        description: Path ZIP in repository',
    '        required: true',
    '        type: string',
    '      apk_name:',
    '        description: Output APK file name',
    '        required: true',
    '        type: string',
    '',
    'permissions:',
    '  contents: write',
    '  actions: read',
    '',
    'jobs:',
    '  build:',
    '    runs-on: ubuntu-latest',
    '    timeout-minutes: 60',
    '',
    '    steps:',
    '      - name: Checkout repository',
    '        uses: actions/checkout@v4',
    '',
    '      - name: Set up Java',
    '        uses: actions/setup-java@v4',
    '        with:',
    '          distribution: temurin',
    "          java-version: '17'",
    '',
    '      - name: Install Flutter SDK manually',
    '        shell: bash',
    '        run: |',
    '          set -euo pipefail',
    '          mkdir -p "$RUNNER_TEMP/flutter"',
    '          cd "$RUNNER_TEMP/flutter"',
    '          curl -fsSL https://storage.googleapis.com/flutter_infra_release/releases/releases_linux.json -o releases.json',
    "          FLUTTER_ARCHIVE=$(python3 - <<'PY'",
    '            import json',
    "            with open('releases.json', 'r', encoding='utf-8') as f:",
    '                data = json.load(f)',
    "            base = data['base_url']",
    "            current = data['current_release']['stable']",
    "            release = next(item for item in data['releases'] if item['hash'] == current)",
    '            print(f"{base}/{release[\'archive\']}")',
    '            PY',
    '          )',
    '          echo "Downloading: $FLUTTER_ARCHIVE"',
    '          curl -fL "$FLUTTER_ARCHIVE" -o flutter.tar.xz',
    '          tar -xf flutter.tar.xz',
    '          echo "$RUNNER_TEMP/flutter/flutter/bin" >> "$GITHUB_PATH"',
    '          echo "$RUNNER_TEMP/flutter/flutter/bin/cache/dart-sdk/bin" >> "$GITHUB_PATH"',
    '          flutter --version',
    '',
    '      - name: Build with captured logs',
    '        id: build_step',
    '        shell: bash',
    '        run: |',
    '          set +e',
    '          export BUILD_ID="${{ github.event.inputs.build_id }}"',
    '          export ZIP_PATH="${{ github.event.inputs.zip_path }}"',
    '          export APK_NAME="${{ github.event.inputs.apk_name }}"',
    '          export GITHUB_WORKSPACE="${GITHUB_WORKSPACE}"',
    '',
    '          rm -rf workdir build-output logs',
    '          mkdir -p workdir/source build-output logs',
    '',
    '          run_and_capture() {',
    '            local name="$1"',
    '            shift',
    '            echo "===== ${name} =====" | tee -a logs/summary.txt',
    '            bash -lc "$*" > >(tee "logs/${name}.log") 2>&1',
    '            local code=$?',
    '            echo "exit_code=${code}" | tee -a "logs/${name}.meta"',
    '            echo "status=${name}:${code}" | tee -a logs/summary.txt',
    '            return $code',
    '          }',
    '',
    '          FINAL_CODE=0',
    '          PROJECT_DIR=""',
    '',
    '          run_and_capture validate_zip "test -f "${ZIP_PATH}"" || FINAL_CODE=$?',
    '',
    '          if [ $FINAL_CODE -eq 0 ]; then',
    '            run_and_capture unzip_source "unzip -o -q "${ZIP_PATH}" -d workdir/source" || FINAL_CODE=$?',
    '          fi',
    '',
    '          if [ $FINAL_CODE -eq 0 ]; then',
    '            if [ -f workdir/source/pubspec.yaml ]; then',
    '              PROJECT_DIR="workdir/source"',
    '            else',
    '              FOUND=$(find workdir/source -maxdepth 5 -type f -name pubspec.yaml | head -n 1 || true)',
    '              if [ -n "$FOUND" ]; then',
    '                PROJECT_DIR=$(dirname "$FOUND")',
    '              else',
    '                echo "pubspec.yaml tidak ditemukan. Pastikan ZIP berisi project Flutter." | tee logs/project_detect.log',
    '                FINAL_CODE=1',
    '              fi',
    '            fi',
    '          fi',
    '',
    '          if [ -n "$PROJECT_DIR" ]; then',
    '            echo "PROJECT_DIR=$PROJECT_DIR" | tee -a logs/summary.txt',
    '          fi',
    '',
    '          if [ $FINAL_CODE -eq 0 ]; then',
    '            run_and_capture flutter_doctor "cd "$PROJECT_DIR" && flutter doctor -v" || FINAL_CODE=$?',
    '          fi',
    '',
    '          if [ $FINAL_CODE -eq 0 ]; then',
    '            run_and_capture flutter_pub_get "cd "$PROJECT_DIR" && flutter pub get" || FINAL_CODE=$?',
    '          fi',
    '',
    '          if [ $FINAL_CODE -eq 0 ]; then',
    '            run_and_capture flutter_build_apk "cd "$PROJECT_DIR" && flutter build apk --release" || FINAL_CODE=$?',
    '          fi',
    '',
    '          if [ $FINAL_CODE -eq 0 ]; then',
    '            APK_PATH=$(find "$PROJECT_DIR/build/app/outputs/flutter-apk" -maxdepth 1 -type f -name "*.apk" | head -n 1 || true)',
    '            if [ -z "$APK_PATH" ]; then',
    '              echo "APK output tidak ditemukan" | tee logs/apk_find.log',
    '              FINAL_CODE=1',
    '            else',
    '              cp "$APK_PATH" "$GITHUB_WORKSPACE/build-output/${APK_NAME}"',
    '            fi',
    '          fi',
    '',
    '          {',
    '            echo "build_id=${BUILD_ID}"',
    '            echo "zip_path=${ZIP_PATH}"',
    '            echo "project_dir=${PROJECT_DIR}"',
    '            echo "final_code=${FINAL_CODE}"',
    '          } >> logs/summary.txt',
    '',
    '          if [ $FINAL_CODE -ne 0 ]; then',
    '            echo "Build gagal dengan kode $FINAL_CODE" | tee -a logs/summary.txt',
    '          else',
    '            echo "Build sukses" | tee -a logs/summary.txt',
    '          fi',
    '',
    '          exit $FINAL_CODE',
    '',
    '      - name: Upload build logs',
    '        if: always()',
    '        uses: actions/upload-artifact@v4',
    '        with:',
    '          name: build-logs-${{ github.event.inputs.build_id }}',
    '          path: logs/',
    '          if-no-files-found: warn',
    '          compression-level: 0',
    '',
    '      - name: Delete old release if exists',
    '        if: success()',
    '        env:',
    '          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}',
    '        shell: bash',
    '        run: |',
    '          set +e',
    '          gh release delete "build-${{ github.event.inputs.build_id }}" --yes',
    '          git push origin :refs/tags/"build-${{ github.event.inputs.build_id }}"',
    '          exit 0',
    '',
    '      - name: Create release and upload APK',
    '        if: success()',
    '        env:',
    '          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}',
    '        shell: bash',
    '        run: |',
    '          set -euo pipefail',
    '          gh release create "build-${{ github.event.inputs.build_id }}" "build-output/${{ github.event.inputs.apk_name }}" --title "Build ${{ github.event.inputs.build_id }}" --notes "APK build otomatis"'
  ].join('\n');
}

async function processBuildRequest(chatId, document) {
  const settings = getChatSettings(chatId);
  if (!settings.owner || !settings.repo || !settings.branch) {
    await sendMessage(chatId, 'Repo GitHub belum diset. Gunakan <code>/setup owner/repo</code> terlebih dahulu.');
    return;
  }
  if (!document || !document.file_id) {
    await sendMessage(chatId, 'Saya butuh file ZIP project Flutter.');
    return;
  }

  const fileName = document.file_name || 'project.zip';
  if (!fileName.toLowerCase().endsWith('.zip')) {
    await sendMessage(chatId, 'File harus berekstensi <code>.zip</code>.');
    return;
  }
  if ((document.file_size || 0) > config.maxZipSizeBytes) {
    await sendMessage(chatId, `File terlalu besar. Batas saat ini ${Math.round(config.maxZipSizeBytes / 1024 / 1024)} MB.`);
    return;
  }

  await sendMessage(chatId, 'ZIP diterima. Saya sedang upload ke GitHub dan memulai build APK.');

  const buildId = randomId('apk');
  const apkName = `${buildId}.apk`;
  try {
    const { buffer } = await getTelegramFile(document.file_id);
    const remoteZipPath = await uploadSourceZip(settings.owner, settings.repo, settings.branch, buffer, fileName, buildId);
    await dispatchWorkflow(settings.owner, settings.repo, settings.branch, {
      build_id: buildId,
      zip_path: remoteZipPath,
      apk_name: apkName
    });

    state.activeBuilds.set(buildId, {
      chatId,
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      buildId,
      apkName,
      startedAt: Date.now(),
      runId: null,
      status: 'queued',
      lastStatusKey: ''
    });

    await sendMessage(chatId, [
      '<b>Build dimulai</b>',
      `ID: <code>${buildId}</code>`,
      `Repo: <code>${escapeHtml(settings.owner)}/${escapeHtml(settings.repo)}</code>`,
      `Branch: <code>${escapeHtml(settings.branch)}</code>`,
      '',
      'Saya akan memantau workflow lalu mengirim APK atau log error ke bot.'
    ].join('\n'));
  } catch (err) {
    log('build error', err);
    await sendMessage(chatId, `Build gagal dimulai.\n\n<code>${escapeHtml(shorten(err.message, 1200))}</code>`);
  }
}

async function monitorBuilds() {
  const builds = Array.from(state.activeBuilds.values());
  for (const build of builds) {
    try {
      if (!build.runId) {
        const run = await findWorkflowRun(build.owner, build.repo, build.branch, build.buildId);
        if (!run) continue;
        build.runId = run.id;
        build.status = run.status;
        await sendMessage(build.chatId, `Workflow GitHub ditemukan untuk <code>${build.buildId}</code>. Status: <code>${escapeHtml(run.status)}</code>.`);
        continue;
      }

      const run = await getRun(build.owner, build.repo, build.runId);
      const statusKey = `${run.status}:${run.conclusion || 'none'}`;
      if (statusKey === build.lastStatusKey) continue;
      build.lastStatusKey = statusKey;

      if (run.status !== 'completed') {
        build.status = run.status;
        continue;
      }

      if (run.conclusion !== 'success') {
        const jobs = await getRunJobs(build.owner, build.repo, build.runId);
        await sendBuildFailureLogs(build, run, jobs);
        state.activeBuilds.delete(build.buildId);
        continue;
      }

      const asset = await findReleaseAsset(build.owner, build.repo, buildTag(build.buildId));
      if (!asset) {
        const jobs = await getRunJobs(build.owner, build.repo, build.runId);
        await sendMessage(build.chatId, 'Build dinyatakan sukses oleh GitHub, tapi file APK belum ditemukan. Saya kirim ringkasan job agar bisa dicek.');
        await sendBuildFailureLogs(build, { ...run, conclusion: 'apk_not_found' }, jobs);
        state.activeBuilds.delete(build.buildId);
        continue;
      }

      const apkBuffer = await downloadReleaseAsset(build.owner, build.repo, asset.id);
      await sendDocument(build.chatId, asset.name, apkBuffer, `Build sukses: ${build.buildId}`);
      await sendMessage(build.chatId, `APK berhasil dikirim untuk build <code>${build.buildId}</code>.`);
      state.activeBuilds.delete(build.buildId);
    } catch (err) {
      log('monitor build error', build.buildId, err);
      if (Date.now() - build.startedAt > config.maxBuildWaitMs) {
        await sendMessage(build.chatId, `Monitoring build <code>${build.buildId}</code> dihentikan karena melewati batas waktu.\n<code>${escapeHtml(shorten(err.message, 900))}</code>`);
        state.activeBuilds.delete(build.buildId);
      }
    }
  }
}

async function resendLastLogs(chatId) {
  const items = state.lastLogsByChat.get(chatId) || [];
  if (!items.length) {
    await sendMessage(chatId, 'Belum ada log error yang tersimpan untuk chat ini.');
    return;
  }
  for (const item of items) {
    await sendDocument(chatId, item.name, item.buffer, 'Log error terakhir');
  }
}

async function handleCommand(message, text) {
  const chatId = message.chat.id;
  const [commandRaw, ...rest] = text.trim().split(/\s+/);
  const command = commandRaw.toLowerCase();
  const arg = rest.join(' ').trim();

  if (command === '/start' || command === '/help') {
    await sendStart(chatId);
    return;
  }

  if (command === '/repo') {
    const settings = getChatSettings(chatId);
    await sendMessage(chatId, [
      '<b>Repo aktif</b>',
      `Owner: <code>${escapeHtml(settings.owner || '-')}</code>`,
      `Repo: <code>${escapeHtml(settings.repo || '-')}</code>`,
      `Branch: <code>${escapeHtml(settings.branch || '-')}</code>`
    ].join('\n'));
    return;
  }

  if (command === '/setup') {
    const value = arg.replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').trim();
    if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(value)) {
      await sendMessage(chatId, 'Format salah. Contoh: <code>/setup namaowner/namarepo</code>');
      return;
    }
    const [owner, repo] = value.split('/');
    const current = getChatSettings(chatId);
    const next = { ...current, owner, repo };
    setChatSettings(chatId, next);
    await sendMessage(chatId, `Repo disimpan: <code>${escapeHtml(owner)}/${escapeHtml(repo)}</code>\nBranch aktif: <code>${escapeHtml(next.branch)}</code>`);
    return;
  }

  if (command === '/branch') {
    if (!/^[A-Za-z0-9._\/-]{1,120}$/.test(arg)) {
      await sendMessage(chatId, 'Nama branch tidak valid.');
      return;
    }
    const current = getChatSettings(chatId);
    const next = { ...current, branch: arg };
    setChatSettings(chatId, next);
    await sendMessage(chatId, `Branch disimpan: <code>${escapeHtml(arg)}</code>`);
    return;
  }

  if (command === '/initrepo') {
    const settings = getChatSettings(chatId);
    if (!settings.owner || !settings.repo || !settings.branch) {
      await sendMessage(chatId, 'Set repo dulu dengan <code>/setup owner/repo</code>.');
      return;
    }
    await sendMessage(chatId, 'Saya sedang menulis workflow build ke repository GitHub Anda.');
    try {
      await initRepoFiles(settings.owner, settings.repo, settings.branch);
      await sendMessage(chatId, [
        '<b>Repository siap</b>',
        `Workflow telah ditulis ke <code>${escapeHtml(settings.owner)}/${escapeHtml(settings.repo)}</code>.`,
        `File workflow: <code>.github/workflows/${escapeHtml(config.workflowFileName)}</code>`,
        '',
        'Sekarang gunakan <code>/build</code> lalu kirim ZIP project Flutter.'
      ].join('\n'));
    } catch (err) {
      await sendMessage(chatId, `Gagal inisialisasi repo.\n\n<code>${escapeHtml(shorten(err.message, 1200))}</code>`);
    }
    return;
  }

  if (command === '/build') {
    state.pendingBuildChats.add(chatId);
    await sendMessage(chatId, 'Silakan kirim file ZIP project Flutter Anda sekarang.');
    return;
  }

  if (command === '/status') {
    const mine = Array.from(state.activeBuilds.values()).filter((item) => item.chatId === chatId);
    if (!mine.length) {
      await sendMessage(chatId, 'Tidak ada build aktif saat ini.');
      return;
    }
    await sendMessage(chatId, mine.map((item) => `• <code>${item.buildId}</code> - <code>${escapeHtml(item.status || 'queued')}</code>`).join('\n'));
    return;
  }

  if (command === '/lastlog') {
    await resendLastLogs(chatId);
    return;
  }

  await sendMessage(chatId, 'Perintah tidak dikenal. Gunakan <code>/help</code>.');
}

async function handleMessage(message) {
  const chatId = message.chat.id;
  const text = message.text || message.caption || '';

  if (text.startsWith('/')) {
    await handleCommand(message, text);
    return;
  }

  if (message.document && state.pendingBuildChats.has(chatId)) {
    state.pendingBuildChats.delete(chatId);
    await processBuildRequest(chatId, message.document);
  }
}

async function pollTelegram() {
  const updates = await telegramCall('getUpdates', {
    timeout: 30,
    offset: state.offset,
    allowed_updates: ['message']
  });

  for (const update of updates) {
    state.offset = update.update_id + 1;
    if (update.message) {
      try {
        await handleMessage(update.message);
      } catch (err) {
        log('handle message error', err);
        try {
          await sendMessage(update.message.chat.id, `Terjadi error internal.\n\n<code>${escapeHtml(shorten(err.message, 1200))}</code>`);
        } catch (_) {}
      }
    }
  }
}

async function startupChecks() {
  if (!config.telegramBotToken || config.telegramBotToken.includes('ISI_')) throw new Error('TELEGRAM_BOT_TOKEN belum diisi.');
  if (!config.githubToken || config.githubToken.includes('ISI_')) throw new Error('GITHUB_TOKEN belum diisi.');
  await telegramCall('getMe', {});
  await githubJson('GET', '/user', null, [200]);
}

async function main() {
  await startupChecks();
  log(`${config.appName} started`);

  setInterval(() => {
    monitorBuilds().catch((err) => log('monitor interval error', err));
  }, config.pollIntervalMs);

  while (true) {
    try {
      await pollTelegram();
    } catch (err) {
      log('poll error', err);
      await sleep(5000);
    }
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
