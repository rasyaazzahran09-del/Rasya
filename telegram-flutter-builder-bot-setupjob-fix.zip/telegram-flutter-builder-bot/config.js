'use strict';

module.exports = {
  appName: process.env.APP_NAME || 'telegram-flutter-zip-builder',

  telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || 'ISI_TELEGRAM_BOT_TOKEN',
  githubToken: process.env.GITHUB_TOKEN || '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',

  defaultRepoOwner: process.env.DEFAULT_REPO_OWNER || 'RasyaFadlil123',
  defaultRepoName: process.env.DEFAULT_REPO_NAME || 'Rasya',
  defaultBranch: process.env.DEFAULT_BRANCH || 'main',

  sourceZipPath: process.env.SOURCE_ZIP_PATH || 'input',
  workflowFileName: process.env.WORKFLOW_FILE_NAME || 'build-flutter-apk.yml',

  maxZipSizeBytes: Number(process.env.MAX_ZIP_SIZE_BYTES || 150 * 1024 * 1024),
  pollIntervalMs: Number(process.env.POLL_INTERVAL_MS || 15000),
  maxBuildWaitMs: Number(process.env.MAX_BUILD_WAIT_MS || 90 * 60 * 1000),

  startPhotoFileId: process.env.START_PHOTO_FILE_ID || 'https://files.catbox.moe/f0cstd.jpg',
  startPhotoUrl: process.env.START_PHOTO_URL || 'https://files.catbox.moe/f0cstd.jpg'
};
